package org.tnsif.customermodule;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
//create table

public class customer {
	
	@Id
	private int id;
	private String name;
	private int ord_id;
	private String ord_date;
	
	//default constuctor
	public customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	//parameterized constructor
	public customer(int id, String name, int ord_id, String ord_date) {
		super();
		this.id = id;
		this.name = name;
		this.ord_id = ord_id;
		this.ord_date = ord_date;
	}
	
	//create getters and setters
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getOrd_id() {
		return ord_id;
	}
	public void setOrd_id(int ord_id) {
		this.ord_id = ord_id;
	}
	public String getOrd_date() {
		return ord_date;
	}
	public void setOrd_date(String ord_date) {
		this.ord_date = ord_date;
	}
		
	// parameterized constructor
	
	

}
