package org.tnsif.customermodule;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {
	
	@Autowired
	private  CustomerRepository customerRepository;
	
	
	public List<customer> getAllCustomers(){
		return customerRepository.findAll();
	}
	
	public customer getCustomerById(Integer id) {
		return customerRepository.findById(id).orElse(null);
	}

	public customer SaveCustomer(customer Customer) {
		return customerRepository.save(Customer);
	}

	public void deleteCustomer(Integer id) {
		customerRepository.deleteById(id);
	}

}
